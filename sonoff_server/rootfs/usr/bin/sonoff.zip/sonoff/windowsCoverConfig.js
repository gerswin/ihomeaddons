var exports = module.exports = {
    "1bcc24f9aaf0": {
        windowState: 100,
        timeUp: 45,
        timeDown: 47,
        oldwindowState:100,
        rf: false,
        runing: false,
        lastValue: false
    }
};
